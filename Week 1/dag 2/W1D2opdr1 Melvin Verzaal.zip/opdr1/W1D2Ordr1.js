<script>
console.log("Hello Winc Academy");
const name = 'Melvin Verzaal';
console.log(name);

let num1 = 1;
let num2 = 5;
console.log (num1 + num2);

console.log (num1 - num2);

console.log (num1 * num2);

console.log (num1 / num2);

console.log (num1 % num2);

var age = 24;
console.log (typeof(age));

var age = 'vierentwintig';
console.log (typeof(age));

    </script>