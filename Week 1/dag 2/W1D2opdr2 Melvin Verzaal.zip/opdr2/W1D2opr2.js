console.log('heeey alooha');

//Dit is een engkele line commet

/* dit 
is
een
meerdere 
line comment
*/ 