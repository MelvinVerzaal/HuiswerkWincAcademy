

console.log("Hallo Winc Academy studenten");

/*
    //Dit is een groote som
        console.log(1230941 * 1823794);

    //dit is ook een groote som
        console.log(637263 / 54);
*/