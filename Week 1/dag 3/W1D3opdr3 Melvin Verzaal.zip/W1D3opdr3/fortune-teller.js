function tellFortune(childers, namePartners, jobTitle, jobTitle){
    let future = 'You will be a ' + jobTitle + ' in ' + jobTitle + ' and married to ' +
    namePartners + ' ' + ' with ' + childers + ' kids.';
   
    console.log(future);
}