function calculateDogAge(age){
    var dogYears = 7*age;
    console.log("Your doggie is " + dogYears + " years old in dog years!");
}