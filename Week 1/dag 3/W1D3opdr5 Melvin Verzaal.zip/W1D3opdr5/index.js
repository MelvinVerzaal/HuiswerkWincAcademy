let colors = ['yellow', 'blue', 'red', 'orange'];
let i = 1; 

while(i  < colors.length){
    console.log(colors[i]);
    i++;
}

for(i =0; i<=colors.length ; i++){
    console.log(colors[i]);
    }

colors.forEach(element => console.log(element));