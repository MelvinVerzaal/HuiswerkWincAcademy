# Double-choc-beet-brownie-recipe
How to make it. 

<<<<<<< HEAD

#DIRECTIONS FOR THE CHOCOLATE MOUSSE

..* Put equal parts of cold water and ice into a medium metal or plastic bowl for the ice bath.

..* Boil the kettle and pour 150 ml of boiling water into a second medium bowl (ideally a metal bowl).

..* Chop the chocolate into small pieces and add to the bowl of boiling water. Stir with a spatula or whisk until all the pieces are melted and it resembles the texture and smoothness of a hot chocolate.

..* Place the bowl with the chocolate over the ice bath where the bottom of the bowl with the chocolate is touching the ice cold water and whisk vigorously. Continue to whisk until the mixture has the consistency of stiff whipped cream, it should take about 3-5 mins.

..* If it gets too thick do not worry, just add a little more boiling water and incorporate it in.

..* Spread generously on top of the cooled brownies. Enjoy!

=======
# H1 Double choc beet brownie

# H2 Ingredients - Piri piri Sauce
 
..* 100 g Almond Flour
 
..* 100 g White Flour
 
..* 200 g Coconut Oil
 
..* 200 ml Maple Syrup
 
..* 60 g Cacao
 
..* 1 tbsp Vanilla Extract
 
..* 200 g Cooked Beetroot (chopped roughly)
 
..* 1 tbsp Baking Powder

# H2 Ingredients for the chocolate mousse
 
..* 200 g Dark Chocolate
 
..* 150 ml Boiling Water
 
..* Ice
>>>>>>> af63b7b73b7d9e12281e2d4dbb7c6899a665d09c

