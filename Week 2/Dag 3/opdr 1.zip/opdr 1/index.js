///A
let ikRockArrowFunctions = () =>  {
  console.log("Joe, ik rock de arrow functions!");
}
ikRockArrowFunctions();

///B
const fivePlusSeven = () =>  5 + 7
fivePlusSeven();

//c
() =>  1 + 2

//D
const myFunction = (a,b) => a + b

//e
const myFunction = a => a + 5

//F
let createObject = () => ({greeting: "hoi"})