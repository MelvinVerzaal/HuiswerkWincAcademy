//a
const arrayWithWords = ["nice","awesome","tof"]
    const addTheWordCool = function(array){
    	array.push("cool");
    }




    console.log("Add cool:", addTheWordCool(["nice", "awesome", "tof"]));
//b
return array.length;


//c
return array[0];

//d
return array[array.lenght - 1];

//E
const newArray = array.slice(1, 4);

//F
return array.join(" ");

//G
return array1.concat(array2);