//1
const superheros =  [
    {
      "name": "Batman",
      "publisher": "DC Comics",
      "alter_ego": "Bruce Wayne",
      "first_appearance": "Detective Comics #27",
      "weight": "210"
    },
    {
      "name": "Superman",
      "publisher": "DC Comics",
      "alter_ego": "Kal-El",
      "first_appearance": "Action Comics #1",
      "weight": "220"
    },
    {
      "name": "Flash",
      "publisher": "DC Comics",
      "alter_ego": "Jay Garrick",
      "first_appearance": "Flash Comics #1",
      "weight": "195"
    },
    {
      "name": "Green Lantern",
      "publisher": "DC Comics",
      "alter_ego": "Alan Scott",
      "first_appearance": "All-American Comics #16",
      "weight": "186"
    },
    {
      "name": "Green Arrow",
      "publisher": "DC Comics",
      "alter_ego": "Oliver Queen",
      "first_appearance": "All-American Comics #16",
      "weight": "195"
    },
    {
      "name": "Wonder Woman",
      "publisher": "DC Comics",
      "alter_ego": "Princess Diana",
      "first_appearance": "The Incredible Hulk #180",
      "weight": "165"
    },
    {
      "name": "Blue Beetle",
      "publisher": "DC Comics",
      "alter_ego": "Dan Garret",
      "first_appearance": "Mystery Men Comics #1",
      "weight": "145"
  },
  {
      "name": "Spider Man",
      "publisher": "Marvel Comics",
      "alter_ego": "Peter Parker",
      "first_appearance": "Amazing Fantasy #15",
      "weight": "167"
  },
  {
      "name": "Captain America",
      "publisher": "Marvel Comics",
      "alter_ego": "Steve Rogers",
      "first_appearance": "Captain America Comics #1",
      "weight": "220"
  },
  {
      "name": "Iron Man",
      "publisher": "Marvel Comics",
      "alter_ego": "Tony Stark",
      "first_appearance": "Tales of Suspense #39",
      "weight": "250"
  },
  {
      "name": "Thor",
      "publisher": "Marvel Comics",
      "alter_ego": "Thor Odinson",
      "first_appearance": "Journey into Myster #83",
      "weight": "200"
  },
  {
      "name": "Hulk",
      "publisher": "Marvel Comics",
      "alter_ego": "Bruce Banner",
      "first_appearance": "The Incredible Hulk #1",
      "weight": "1400"
  },
  {
      "name": "Wolverine",
      "publisher": "Marvel Comics",
      "alter_ego": "James Howlett",
      "first_appearance": "The Incredible Hulk #180",
      "weight": "200"
  },
  {
      "name": "Daredevil",
      "publisher": "Marvel Comics",
      "alter_ego": "Matthew Michael Murdock",
      "first_appearance": "Daredevil #1",
      "weight": "200"
  },
  {
      "name": "Silver Surfer",
      "publisher": "Marvel Comics",
      "alter_ego": "Norrin Radd",
      "first_appearance": "The Fantastic Four #48",
      "weight": "unknown"
    }
  ];

//2
  const lichteSuperhelden = superheros.filter(n =>  n.weight < 190  );
 // console.log(lichteSuperhelden );

//3
 let superheros200 = superheros.filter(n =>  n.weight == 200  );
 const SuperheldenTohonderd = superheros200.map(n=> n.name);
  //console.log(SuperheldenTohonderd );

//4
  const SuperheldenAppearances= superheros.map(n=> n.first_appearance);
  //console.log(SuperheldenAppearances );
//5
  let superherosPublisher = superheros.filter(n =>  n.publisher ==  'DC Comics'  );
  const superherosPublisherDC = superherosPublisher.map(n=> n.name);
  //console.log(superherosPublisherDC );

  superherosPublisher = superheros.filter(n =>  n.publisher ==  'Marvel Comics'  );
  const superherosPublisherMarvel = superherosPublisher.map(n=> n.name);
  //console.log(superherosPublisherMarvel );

//6
superherosPublisher = superheros.filter(n => { return n.publisher ==  'DC Comics'});
let superherosPublisherweight = superherosPublisher.map(n=> n.weight);
let totalweight = superherosPublisherweight.reduce((accumulator , currentValue) => accumulator + currentValue );
 console.log(totalweight);


//7
superherosPublisher = superheros.filter(n => { return n.publisher == 'Marvel Comics' && n.weight != 'unknown' });
superherosPublisherweight = superherosPublisher.map(n=> n.weight);
totalweight = superherosPublisherweight.reduce((accumulator , currentValue) => accumulator+currentValue );
 console.log(totalweight);